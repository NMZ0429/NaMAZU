__version__ = "0.0.14"

import NaMAZU.lightning_wingman
import NaMAZU.functional

# rm -rf build dist NaMAZU.egg-info
# python setup.py bdist_wheel
# twine upload dist/*
