__version__ = "0.0.72"

import NaMAZU.lightning_wingman
import NaMAZU.functional
import NaMAZU.st_integration
import NaMAZU.namadeco
import NaMAZU.onnx_api
