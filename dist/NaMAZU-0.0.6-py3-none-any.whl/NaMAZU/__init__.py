__version__ = "0.0.6"

import NaMAZU.functional

# rm -rf build dist NaMAZU.egg-info
# python setup.py bdist_wheel
# twine upload dist/*
