__version__ = "0.0.5"

import NaMAZU.functional

