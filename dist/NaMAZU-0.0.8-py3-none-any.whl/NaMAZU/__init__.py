__version__ = "0.0.8"

import NaMAZU.functional
import NaMAZU.lightning_wingman

# rm -rf build dist NaMAZU.egg-info
# python setup.py bdist_wheel
# twine upload dist/*
